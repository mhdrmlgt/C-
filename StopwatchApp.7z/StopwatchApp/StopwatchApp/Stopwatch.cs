using System;

public delegate void StopwatchEventHandler(string message);

public class Stopwatch
{
    private int TimeElapsed { get; set; }
    public bool IsRunning { get; private set; } // Changed to public

    public event StopwatchEventHandler OnStarted;
    public event StopwatchEventHandler OnStopped;
    public event StopwatchEventHandler OnReset;

    public void Start()
    {
        if (!IsRunning)
        {
            IsRunning = true;
            OnStarted?.Invoke("Stopwatch Started!");
        }
    }

    public void Stop()
    {
        if (IsRunning)
        {
            IsRunning = false;
            OnStopped?.Invoke("Stopwatch Stopped!");
        }
    }

    public void Reset()
    {
        TimeElapsed = 0;
        OnReset?.Invoke("Stopwatch Reset!");
    }

    public void Tick()
    {
        if (IsRunning)
        {
            TimeElapsed++;
            Console.WriteLine($"Time Elapsed: {TimeElapsed} seconds");
        }
    }
}
