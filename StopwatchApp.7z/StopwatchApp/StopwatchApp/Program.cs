﻿using System;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        Stopwatch stopwatch = new Stopwatch();

        // Subscribe to events
        stopwatch.OnStarted += HandleEvent;
        stopwatch.OnStopped += HandleEvent;
        stopwatch.OnReset += HandleEvent;

        Console.WriteLine("Console Stopwatch");
        Console.WriteLine("Press S to Start, T to Stop, R to Reset, and Q to Quit.");

        bool quit = false;

        while (!quit)
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Tick();
            }

            // Check for user input
            if (Console.KeyAvailable)
            {
                var key = Console.ReadKey(intercept: true).Key;

                switch (key)
                {
                    case ConsoleKey.S:
                        stopwatch.Start();
                        break;
                    case ConsoleKey.T:
                        stopwatch.Stop();
                        break;
                    case ConsoleKey.R:
                        stopwatch.Reset();
                        break;
                    case ConsoleKey.Q:
                        quit = true;
                        stopwatch.Stop();
                        Console.WriteLine("Exiting Stopwatch...");
                        break;
                }
            }

            Thread.Sleep(1000); // Simulate ticking every second
        }
    }

    private static void HandleEvent(string message)
    {
        Console.WriteLine(message);
    }
}
